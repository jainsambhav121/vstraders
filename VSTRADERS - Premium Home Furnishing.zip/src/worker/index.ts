import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Auth endpoints
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });
  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();
  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }
  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });
  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });
  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }
  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });
  return c.json({ success: true }, 200);
});

// Categories endpoint
app.get("/api/categories", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM categories ORDER BY display_order ASC"
  ).all();
  return c.json(results);
});

// Products endpoints
app.get("/api/products", async (c) => {
  const category = c.req.query("category");
  const featured = c.req.query("featured");
  const trending = c.req.query("trending");
  const search = c.req.query("search");
  
  let query = "SELECT * FROM products WHERE 1=1";
  const params: any[] = [];
  
  if (category) {
    query += " AND category_id = ?";
    params.push(category);
  }
  if (featured === "true") {
    query += " AND is_featured = 1";
  }
  if (trending === "true") {
    query += " AND is_trending = 1";
  }
  if (search) {
    query += " AND (name LIKE ? OR description LIKE ?)";
    params.push(`%${search}%`, `%${search}%`);
  }
  
  query += " ORDER BY created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  return c.json(results);
});

app.get("/api/products/:slug", async (c) => {
  const slug = c.req.param("slug");
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE slug = ?"
  ).bind(slug).first();
  
  if (!product) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  return c.json(product);
});

// Cart endpoints
app.get("/api/cart", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT ci.*, p.name, p.price, p.image_url, p.stock_quantity
    FROM cart_items ci
    JOIN products p ON ci.product_id = p.id
    WHERE ci.user_id = ?
    ORDER BY ci.created_at DESC
  `).bind(user.id).all();
  
  return c.json(results);
});

app.post("/api/cart", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const { product_id, quantity } = await c.req.json();
  
  const existing = await c.env.DB.prepare(
    "SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?"
  ).bind(user.id, product_id).first();
  
  if (existing) {
    await c.env.DB.prepare(
      "UPDATE cart_items SET quantity = quantity + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(quantity || 1, existing.id).run();
  } else {
    await c.env.DB.prepare(
      "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)"
    ).bind(user.id, product_id, quantity || 1).run();
  }
  
  return c.json({ success: true });
});

app.put("/api/cart/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const id = c.req.param("id");
  const { quantity } = await c.req.json();
  
  await c.env.DB.prepare(
    "UPDATE cart_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(quantity, id, user.id).run();
  
  return c.json({ success: true });
});

app.delete("/api/cart/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM cart_items WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).run();
  
  return c.json({ success: true });
});

// Wishlist endpoints
app.get("/api/wishlist", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT wi.*, p.name, p.price, p.image_url, p.slug
    FROM wishlist_items wi
    JOIN products p ON wi.product_id = p.id
    WHERE wi.user_id = ?
    ORDER BY wi.created_at DESC
  `).bind(user.id).all();
  
  return c.json(results);
});

app.post("/api/wishlist", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const { product_id } = await c.req.json();
  
  const existing = await c.env.DB.prepare(
    "SELECT * FROM wishlist_items WHERE user_id = ? AND product_id = ?"
  ).bind(user.id, product_id).first();
  
  if (existing) {
    return c.json({ success: true });
  }
  
  await c.env.DB.prepare(
    "INSERT INTO wishlist_items (user_id, product_id) VALUES (?, ?)"
  ).bind(user.id, product_id).run();
  
  return c.json({ success: true });
});

app.delete("/api/wishlist/:id", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM wishlist_items WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).run();
  
  return c.json({ success: true });
});

export default app;
