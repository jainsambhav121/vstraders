import { Award, Users, Truck, Shield } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">About VSTRADERS</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Your trusted partner in premium home furnishing since 2015
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              VSTRADERS began with a simple mission: to provide premium quality home furnishing products that combine comfort, style, and affordability. Over the years, we've grown from a small local store to a trusted e-commerce platform serving thousands of customers nationwide.
            </p>
            <p className="text-gray-600 leading-relaxed mb-4">
              We carefully curate our collection of pillows, mattresses, covers, and sofas from the finest manufacturers, ensuring every product meets our rigorous quality standards. Our commitment to customer satisfaction has made us a household name in home furnishing.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Today, VSTRADERS continues to innovate and expand, always keeping our customers' comfort and happiness at the heart of everything we do.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800"
              alt="About VSTRADERS"
              className="rounded-2xl shadow-2xl"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Premium Quality</h3>
            <p className="text-gray-600">
              Only the finest materials and craftsmanship
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">50K+ Customers</h3>
            <p className="text-gray-600">
              Trusted by families across the country
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Truck className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Fast Delivery</h3>
            <p className="text-gray-600">
              Quick and reliable shipping nationwide
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Secure Shopping</h3>
            <p className="text-gray-600">
              Safe and protected transactions
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Join the VSTRADERS Family</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Experience the perfect blend of comfort, quality, and style. Transform your living space today.
          </p>
        </div>
      </div>
    </div>
  );
}
