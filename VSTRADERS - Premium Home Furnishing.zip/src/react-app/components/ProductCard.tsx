import { Link } from "react-router";
import { Star, Heart } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import type { Product } from "@/shared/types";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { user } = useAuth();
  const [isWishlisted, setIsWishlisted] = useState(false);

  const discountPercentage = product.compare_at_price
    ? Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)
    : 0;

  const handleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      if (isWishlisted) {
        await fetch(`/api/wishlist/${product.id}`, { method: "DELETE" });
        setIsWishlisted(false);
      } else {
        await fetch("/api/wishlist", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ product_id: product.id }),
        });
        setIsWishlisted(true);
      }
    } catch (error) {
      console.error("Wishlist error:", error);
    }
  };

  return (
    <Link
      to={`/product/${product.slug}`}
      className="group relative bg-white rounded-2xl overflow-hidden border border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300"
    >
      {discountPercentage > 0 && (
        <div className="absolute top-4 left-4 z-10 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs font-bold px-3 py-1 rounded-full">
          {discountPercentage}% OFF
        </div>
      )}
      
      {user && (
        <button
          onClick={handleWishlist}
          className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
        >
          <Heart
            className={`w-5 h-5 ${
              isWishlisted ? "fill-red-500 text-red-500" : "text-gray-600"
            }`}
          />
        </button>
      )}

      <div className="aspect-square overflow-hidden bg-gray-100">
        <img
          src={product.image_url || "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400"}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
          {product.name}
        </h3>

        <div className="flex items-center space-x-1 mb-3">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-4 h-4 ${
                i < Math.floor(product.rating)
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-300"
              }`}
            />
          ))}
          <span className="text-sm text-gray-600 ml-2">
            ({product.review_count})
          </span>
        </div>

        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold text-gray-900">
            ₹{product.price.toLocaleString()}
          </span>
          {product.compare_at_price && (
            <span className="text-sm text-gray-500 line-through">
              ₹{product.compare_at_price.toLocaleString()}
            </span>
          )}
        </div>

        {product.stock_quantity < 10 && product.stock_quantity > 0 && (
          <p className="text-xs text-orange-600 mt-2 font-medium">
            Only {product.stock_quantity} left in stock!
          </p>
        )}
        {product.stock_quantity === 0 && (
          <p className="text-xs text-red-600 mt-2 font-medium">Out of stock</p>
        )}
      </div>
    </Link>
  );
}
