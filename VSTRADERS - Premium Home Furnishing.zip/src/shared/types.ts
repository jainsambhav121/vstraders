import z from "zod";

export const CategorySchema = z.object({
  id: z.number(),
  name: z.string(),
  slug: z.string(),
  description: z.string().nullable(),
  image_url: z.string().nullable(),
  parent_id: z.number().nullable(),
  display_order: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ProductSchema = z.object({
  id: z.number(),
  name: z.string(),
  slug: z.string(),
  description: z.string().nullable(),
  price: z.number(),
  compare_at_price: z.number().nullable(),
  category_id: z.number().nullable(),
  stock_quantity: z.number(),
  sku: z.string().nullable(),
  image_url: z.string().nullable(),
  gallery_images: z.string().nullable(),
  is_featured: z.number(),
  is_trending: z.number(),
  rating: z.number(),
  review_count: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CartItemSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  product_id: z.number(),
  quantity: z.number(),
  name: z.string(),
  price: z.number(),
  image_url: z.string().nullable(),
  stock_quantity: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const WishlistItemSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  product_id: z.number(),
  name: z.string(),
  price: z.number(),
  image_url: z.string().nullable(),
  slug: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Category = z.infer<typeof CategorySchema>;
export type Product = z.infer<typeof ProductSchema>;
export type CartItem = z.infer<typeof CartItemSchema>;
export type WishlistItem = z.infer<typeof WishlistItemSchema>;
